package school;

import java.util.Arrays;


public class Grade {

	private String []professions= {"MATH", "CHEMISTRY", "GEOGRAPHY", "LITERATURE", "PHYSICS", "SPORTS"};
	private String profession;
	private int score;
	private  int i=0;

	
	public Grade() {
		super();
			if(i<6)
	this.profession= professions[i];
		i++;
		this.score = (int)(Math.random()*61)+40;
	
	}


	@Override
	public String toString() {
		return " [profession - " + profession + ", score - " + score +  "]";
	}


	




	public String getProfession() {
		return profession;
	}


	public int getScore() {
		return score;
	}
	
	
	

	
}
