package school;

import java.util.Arrays;

public class Teacher extends Person {
	
	private String []professions= {"MATH", "CHEMISTRY", "GEOGRAPHY", "LITERATURE", "PHYSICS", "SPORTS"};
	private String profession;
	private  int i=0;

	private static int d=1;

	
	public Teacher() {
		super();
		super.setName("Teaher" + d++);
		if(i<6)
			this.profession=	professions[i];
				i++;
	}

	
	
	

	public String[] getProfessions() {
		return professions;
	}





	public String getProfession() {
		return profession;
	}





	@Override
	public String toString() {
		return  super.toString() + " profession " +profession;
	}

	
	
}
